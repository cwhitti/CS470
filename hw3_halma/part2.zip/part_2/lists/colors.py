colors = {
        "red":
            (
                "#ff2626", # main color
                "#ffbdbd"  # home color
            ),
        "gray":
            (
                "#5f5f5f", # main color
                "#b2b2b2"  # home color
            ),
        
        "green":
            (
                "#36b200", # main color
                "#c3e9b3"  # home color
            ),
        "blue":
            (
                "#3e8bc2", # main color
                "#a1cff0"  # home color
            ),
        "pink":
            (
                "#ff91ef", # main color
                "#fcd4f6"  # home color
            ),
        
        }